from sklearn.datasets import load_breast_cancer
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from controller import HyperHeuristicController
from models.random_search import random_search
from models.optuna_bo import optuna_bo
from models.successive_halving import successive_halving
from models.hyperband_simple import hyperband_simple
from models.model_config import get_model_config

from meta_features import extract_meta_features
from datasets.dataset_loader import load_dataset
from datasets.preprocessors import preprocess_dataset

import logging
import os
import csv
import numpy as np

# SISTEMA DE LOGS CON MLFLOW
import mlflow

mlflow.set_experiment("hyperheuristic_experiment")


# SISTEMA DE LOGS
os.makedirs("logs", exist_ok=True)

logging.basicConfig(
    filename="logs/hh.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

available_models = ["rf", "svm"]
available_heuristics = ["random", "optuna", "sh", "hb"]


def run_experiment(dataset_name, dataset_path=None):

    # MLF LOG
    mlflow.start_run()

    # === cargar dataset temporal ===
    X, y = load_dataset(dataset_name, dataset_path)
    X_train, X_test, y_train, y_test = preprocess_dataset(X, y)

    # EXTRACCION DE META-FEATURES
    meta = extract_meta_features(X_train, y_train)

    # MLF LOG
    mlflow.log_params(meta)

    # NUEVO DE HPO A CASH, AQUI SON LAS COMBINACIONES POSIBLES
    actions = [f"{m}_{h}" for m in available_models for h in available_heuristics]

    # CREACION DEL CONTROLADOR (HH)
    controller = HyperHeuristicController(heuristics=actions, meta_features=meta)

    best_score = -1
    best_params = None
    best_model_name = None

    # SISTEMA DE LOGS EN CSV
    csv_path = "logs/results.csv"
    csv_exists = os.path.isfile(csv_path)

    csv_file = open(csv_path, "a", newline="")
    csv_writer = csv.writer(csv_file)

    # si el archivo es nuevo => agregar cabecera
    if not csv_exists:
        csv_writer.writerow(
            [
                "round",
                "method",
                "score",
                "best_score",
                "params",
                "controller_values",
                "controller_counts",
            ]
        )

    # BUCLE DE RONDAS
    for i in range(20):  # <--- Nº de rondas ajustable

        selected_action = controller.select()
        model_name, method_name = selected_action.split("_")

        logging.info(f"Ronda {i} — Modelo: {model_name} | Método: {method_name}")

        if method_name == "random":
            model, param_dist = get_model_config(model_name, "random")
            score, params = random_search(model, param_dist, X_train, y_train, iters=8)

        elif method_name == "optuna":
            # Para Optuna necesitamos una lambda que envuelva el get_model_config
            def sampler(t):
                _, p = get_model_config(model_name, "optuna", trial=t)
                return p

            # Necesitamos pasar la CLASE del modelo, no la instancia, a tu función optuna_bo
            model_class = get_model_config(model_name, "random")[0].__class__
            score, params = optuna_bo(model_class, sampler, X_train, y_train, trials=8)

        elif method_name == "sh":
            model, param_dist = get_model_config(model_name, "sh")
            score, params = successive_halving(model, param_dist, X_train, y_train)

        elif method_name == "hb":
            # HB en tu código espera una lambda para param_sampler
            model_inst, _ = get_model_config(model_name, "hb")
            model_class = model_inst.__class__

            param_sampler = lambda: get_model_config(model_name, "hb")[1]

            score, params = hyperband_simple(
                model_class, param_sampler, X_train, y_train
            )

        logging.info(f"Score obtenido: {score}")
        logging.info(f"Params: {params}")

        # MLF LOG
        mlflow.log_metric(f"score_round_{i}", score)
        mlflow.log_param(f"heuristic_round_{i}", method_name)

        controller.update(selected_action, score)
        logging.info(f"Valores actualizados del controlador: {controller.values}")
        logging.info(f"Usos: {controller.counts}")

        csv_writer.writerow(
            [
                i,
                method_name,
                score,
                best_score,
                str(params),
                str(controller.values.copy()),
                str(controller.counts.copy()),
            ]
        )

        if score > best_score:
            best_score, best_params, best_model_name = score, params, model_name

    logging.info(f"Ganador absoluto: {best_model_name} con params {best_params}")

    # 1. Obtenemos una instancia vacía del modelo ganador
    # Usamos 'random' como método dummy, solo queremos la instancia del modelo
    final_model, _ = get_model_config(best_model_name, "random")

    # 2. Le inyectamos los mejores parámetros encontrados
    final_model.set_params(**best_params)

    # 3. Entrenamos
    final_model.fit(X_train, y_train)
    preds = final_model.predict(X_test)

    # MLF LOG
    mlflow.log_metric("best_score", best_score)
    mlflow.log_params(best_params)
    mlflow.end_run()

    logging.info(f"BEST SCORE FINAL: {best_score}")
    logging.info(f"F1 FINAL TEST: {f1_score(y_test, preds, average='macro')}")

    csv_file.close()


if __name__ == "__main__":
    run_experiment("ufc", dataset_path="data/fights_processed.csv")
    # run_experiment("iris")
