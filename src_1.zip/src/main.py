from sklearn.datasets import load_breast_cancer
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

from controller import HyperHeuristicController
from models.random_search import random_search
from models.optuna_bo import optuna_bo
from models.successive_halving import successive_halving
from models.hyperband_simple import hyperband_simple

from meta_features import extract_meta_features
from datasets.dataset_loader import load_dataset
from datasets.preprocessors import preprocess_dataset

import logging
import os
import csv
import numpy as np

# SISTEMA DE LOGS CON MLFLOW
import mlflow

mlflow.set_experiment("hyperheuristic_experiment")


# SISTEMA DE LOGS
os.makedirs("logs", exist_ok=True)

logging.basicConfig(
    filename="logs/hh.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)


def run_experiment(dataset_name, dataset_path=None):

    # MLF LOG
    mlflow.start_run()

    # === cargar dataset temporal ===
    X, y = load_dataset(dataset_name, dataset_path)
    X_train, X_test, y_train, y_test = preprocess_dataset(X, y)

    # EXTRACCION DE META-FEATURES
    meta = extract_meta_features(X_train, y_train)

    # MLF LOG
    mlflow.log_params(meta)

    # CREACION DEL CONTROLADOR (HH)
    controller = HyperHeuristicController(
        heuristics=["random", "optuna", "sh", "hb"], meta_features=meta
    )

    best_score = -1
    best_params = None

    # SISTEMA DE LOGS EN CSV
    csv_path = "logs/results.csv"
    csv_exists = os.path.isfile(csv_path)

    csv_file = open(csv_path, "a", newline="")
    csv_writer = csv.writer(csv_file)

    # si el archivo es nuevo => agregar cabecera
    if not csv_exists:
        csv_writer.writerow(
            [
                "round",
                "method",
                "score",
                "best_score",
                "params",
                "controller_values",
                "controller_counts",
            ]
        )

    # BUCLE DE RONDAS
    for i in range(10):  # <--- Nº de rondas ajustable

        method = controller.select()
        logging.info(f"Ronda {i} — usando método: {method}")

        if method == "random":
            score, params = random_search(
                model=RandomForestClassifier(),
                param_dist={
                    "n_estimators": [50, 100, 150],
                    "max_depth": [5, 10, 20, None],
                },
                X=X_train,
                y=y_train,
                iters=8,
            )
        elif method == "optuna":
            score, params = optuna_bo(
                model_class=RandomForestClassifier,
                sampler_fn=lambda t: {
                    "n_estimators": t.suggest_int("n_estimators", 50, 200),
                    "max_depth": t.suggest_int("max_depth", 5, 20),
                },
                X=X_train,
                y=y_train,
                trials=8,
            )
        elif method == "sh":   # nuevo
            score, params = successive_halving(
                model=RandomForestClassifier(),
                param_dist={
                    "n_estimators": [50, 100, 200, 300],
                    "max_depth": [5, 10, 15, 20],
                },
                X=X_train,
                y=y_train
            )
        elif method == "hb":   # nuevo
            score, params = hyperband_simple(
                model_class=RandomForestClassifier,
                param_sampler=lambda: {
                    "n_estimators": np.random.randint(50, 300),
                    "max_depth": np.random.randint(5, 20)
                },
                X=X_train,
                y=y_train
            )

        logging.info(f"Score obtenido: {score}")
        logging.info(f"Params: {params}")

        # MLF LOG
        mlflow.log_metric(f"score_round_{i}", score)
        mlflow.log_param(f"heuristic_round_{i}", method)

        controller.update(method, score)
        logging.info(f"Valores actualizados del controlador: {controller.values}")
        logging.info(f"Usos: {controller.counts}")

        csv_writer.writerow(
            [
                i,
                method,
                score,
                best_score,
                str(params),
                str(controller.values.copy()),
                str(controller.counts.copy()),
            ]
        )

        if score > best_score:
            best_score, best_params = score, params

    model = RandomForestClassifier(**best_params).fit(X_train, y_train)
    preds = model.predict(X_test)

    # MLF LOG
    mlflow.log_metric("best_score", best_score)
    mlflow.log_params(best_params)
    mlflow.end_run()

    logging.info(f"BEST SCORE FINAL: {best_score}")
    logging.info(f"F1 FINAL TEST: {f1_score(y_test, preds, average='macro')}")

    csv_file.close()


if __name__ == "__main__":
    run_experiment("ufc", dataset_path="data/fights_processed.csv")
    # run_experiment("iris")
