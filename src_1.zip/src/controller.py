import numpy as np

class HyperHeuristicController:
    def __init__(self, heuristics, meta_features, epsilon=0.2):
        self.heuristics = heuristics
        self.meta = meta_features
        self.epsilon = epsilon

        # Valor de cada heurística (score esperado)
        self.values = {h: 0.0 for h in heuristics}
        self.counts = {h: 0 for h in heuristics}

        # Sesgo inicial según meta-features (importante!)
        self.bias = self._compute_bias()

    def _compute_bias(self):
        """Señal inicial basada en meta-features."""
        bias = {}

        for h in self.heuristics:
            if h == "optuna":
                # BO funciona mejor en datasets pequeños
                bias[h] = -0.001 * self.meta["n_samples"]
            elif h == "random":
                # Random Search funciona mejor cuando n_features es grande
                bias[h] = +0.001 * self.meta["n_features"]
            elif h == "sh":
                bias[h] = +0.002 * self.meta["n_features"]   # SH escala bien con alta dimensionalidad
            elif h == "hb":
                bias[h] = -0.002 * self.meta["n_samples"]    # HB mejor en datasets medianos
            else:
                bias[h] = 0

        return bias

    # Exploration con UCB
    def select(self):
        total_uses = sum(self.counts[h] for h in self.heuristics) + 1

        def ucb(h):
            if self.counts[h] == 0:
                return float('inf')
            exploit = self.values[h] + self.bias[h]
            explore = np.sqrt(np.log(total_uses) / self.counts[h])
            return exploit + 0.1 * explore  # α = 0.1 tunable

        return max(self.heuristics, key=ucb)

    def update(self, h, score):

        reward = (score - 0.5) * 2  # convertir a rango [-1, 1]

        self.counts[h] += 1
        n = self.counts[h]

        # incremental mean update
        self.values[h] += (reward - self.values[h]) / n
